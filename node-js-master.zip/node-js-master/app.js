module.exports={
    x:10,
    y:20,
    xyz:function()
    {
        return 10+20;
    }
}